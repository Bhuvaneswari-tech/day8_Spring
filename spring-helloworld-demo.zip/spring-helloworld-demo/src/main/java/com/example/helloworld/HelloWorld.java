package com.example.helloworld;

//POJO class
public class HelloWorld {
	String message;
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void printMessage() {
		System.out.println("Your Message: " + message);
	}
}
